# Este es un módulo con funciones que saludan

def despedirse():
    print("Adios, Me estoy despidiendo desde la funcion despedirse del midulo despedidas")
    
class Despedida():
    def __init__(self):
        print("Adios, Me estoy despidiendo desde init de la clase despedida")