# Este es un módulo con funciones que saludan

def saludar():
    print("Te estoy saludando desde la funcion saludar en saludos.py")
    
class Saludo():
    def __init__(self):
        print("Hola, te estoy saludando desde el init de la clase saludo")