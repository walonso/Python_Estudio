# -*- coding: utf-8 -*-
"""
Created on Thu Jun  6 16:50:17 2019

@author: walonsor
"""

from setuptools import setup

setup(name="paquete", 
      version="0.1",
      description="Este es un paquete de ejemplo",
      autor="Walter Alonso",
      author_email="walteralonso20@yahoo.com",
      script=[], # para asociar varios ficheros (no dentro de paquetes)
      packages=["paquete", "paquete.adios", "paquete.hola"] # se colocan los paquetes, primero el grande.. luego los subpaquetes.
)

#creamos el distribuible: (como un instalador)
###
# Se debe abrir en el terminal ubicado en la carpeta padre (donde esta este archivo)
# para este caso: E:\Walonso\Estudio\Python\Python_Estudio\3 Temas avanzados\1 Modulos\2 Paquetes y modulos\2 Paquete distribuible (instalar en python)
# y se ejecuta el comando: python setup.py sdist